package com.officerj.autospa.giveaway

import android.animation.Animator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.BitmapDrawable
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class WheelView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private data class WheelSegment(
        val displayName: String,
        val tickets: List<Pair<Int, String>>
    ) {
        val weight: Int get() = tickets.size
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create(
            android.graphics.Typeface.DEFAULT,
            android.graphics.Typeface.BOLD
        )
    }

    private val logo: Bitmap? by lazy {
        (ContextCompat.getDrawable(context, R.drawable.officer_j_logo) as? BitmapDrawable)?.bitmap
    }

    var tickets: List<Pair<Int, String>> = emptyList()
        set(value) {
            field = value
            segments = buildSegments(value)
            invalidate()
        }

    private var segments: List<WheelSegment> = emptyList()
    private var rotationDegrees = 0f
    var spinning = false
        private set

    /**
     * Selects one numbered ticket at random. Duplicate names are drawn as one larger
     * weighted slice, but every numbered ticket keeps an equal chance of winning.
     */
    fun spin(onWinner: (Pair<Int, String>) -> Unit) {
        if (spinning || tickets.isEmpty() || segments.isEmpty()) return

        spinning = true
        val winningTicket = tickets[Random.nextInt(tickets.size)]
        val winningSegmentIndex = segments.indexOfFirst { segment ->
            segment.tickets.any { it.first == winningTicket.first }
        }.coerceAtLeast(0)

        val totalWeight = tickets.size.toFloat()
        var startAngle = 0f
        for (index in 0 until winningSegmentIndex) {
            startAngle += 360f * segments[index].weight / totalWeight
        }
        val winningSweep = 360f * segments[winningSegmentIndex].weight / totalWeight
        val segmentCenter = startAngle + winningSweep / 2f

        // Android arcs begin at 3 o'clock. The fixed pointer is at 12 o'clock (270°).
        val current = normalizeDegrees(rotationDegrees)
        val currentSegmentCenter = normalizeDegrees(segmentCenter + current)
        val additionalToPointer = normalizeDegrees(270f - currentSegmentCenter)
        val target = rotationDegrees + (360f * 8f) + additionalToPointer

        ValueAnimator.ofFloat(rotationDegrees, target).apply {
            duration = 5000L
            interpolator = DecelerateInterpolator(2.1f)
            addUpdateListener {
                rotationDegrees = it.animatedValue as Float
                invalidate()
            }
            addListener(object : Animator.AnimatorListener {
                override fun onAnimationStart(animation: Animator) = Unit
                override fun onAnimationRepeat(animation: Animator) = Unit
                override fun onAnimationCancel(animation: Animator) {
                    spinning = false
                }
                override fun onAnimationEnd(animation: Animator) {
                    rotationDegrees = normalizeDegrees(rotationDegrees)
                    spinning = false
                    invalidate()
                    onWinner(winningTicket)
                }
            })
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val size = min(width, height).toFloat()
        val pad = size * 0.07f
        val radius = size / 2f - pad
        val cx = width / 2f
        val cy = height / 2f

        paint.style = Paint.Style.FILL
        paint.color = 0xFF07111F.toInt()
        canvas.drawCircle(cx, cy, radius + 10f, paint)

        if (segments.isEmpty()) {
            textPaint.textSize = size * 0.055f
            textPaint.color = Ui.MUTED
            canvas.drawText("ADD ENTRIES TO SPIN", cx, cy, textPaint)
            drawPointer(canvas, cx, cy - radius - 2f, size)
            return
        }

        canvas.save()
        canvas.rotate(rotationDegrees, cx, cy)

        val wheelRect = RectF(cx - radius, cy - radius, cx + radius, cy + radius)
        val totalWeight = tickets.size.toFloat()
        var startAngle = 0f

        segments.forEachIndexed { index, segment ->
            val sweep = 360f * segment.weight / totalWeight

            paint.style = Paint.Style.FILL
            paint.color = if (index % 2 == 0) 0xFF0E1A29.toInt() else 0xFF075BC4.toInt()
            canvas.drawArc(wheelRect, startAngle, sweep, true, paint)

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = if (segments.size > 300) 0.5f else 1.5f
            paint.color = 0xFF6EAFFF.toInt()
            canvas.drawArc(wheelRect, startAngle, sweep, true, paint)
            paint.style = Paint.Style.FILL

            drawSegmentName(
                canvas = canvas,
                name = segment.displayName,
                centerAngle = startAngle + sweep / 2f,
                sweep = sweep,
                cx = cx,
                cy = cy,
                radius = radius,
                wheelSize = size
            )

            startAngle += sweep
        }

        canvas.restore()

        paint.color = 0xFF05070A.toInt()
        canvas.drawCircle(cx, cy, radius * 0.25f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.color = Ui.BLUE
        canvas.drawCircle(cx, cy, radius * 0.25f, paint)
        paint.style = Paint.Style.FILL

        logo?.let { bitmap ->
            val half = (radius * 0.19f).toInt()
            canvas.drawBitmap(
                bitmap,
                null,
                Rect(
                    (cx - half).toInt(),
                    (cy - half).toInt(),
                    (cx + half).toInt(),
                    (cy + half).toInt()
                ),
                paint
            )
        }

        drawPointer(canvas, cx, cy - radius - 2f, size)
    }

    private fun drawSegmentName(
        canvas: Canvas,
        name: String,
        centerAngle: Float,
        sweep: Float,
        cx: Float,
        cy: Float,
        radius: Float,
        wheelSize: Float
    ) {
        // Every unique entrant is rendered, even on very large wheels. Text scales down
        // as slices narrow. At extreme counts Android will still draw the names, although
        // physical phone resolution limits how legible hundreds of labels can be at once.
        val density = resources.displayMetrics.scaledDensity
        val sweepFactor = (sweep / 18f).coerceIn(0.12f, 1f)
        val countFactor = when {
            segments.size <= 16 -> 1f
            segments.size <= 40 -> 0.82f
            segments.size <= 100 -> 0.60f
            segments.size <= 300 -> 0.42f
            else -> 0.28f
        }
        textPaint.textSize = max(2.5f * density, wheelSize * 0.035f * sweepFactor * countFactor)
        textPaint.color = Color.WHITE

        val availableRadialWidth = radius * 0.58f
        val label = fitText(name, availableRadialWidth, textPaint)
        val textRadius = radius * 0.67f

        canvas.save()
        canvas.rotate(centerAngle, cx, cy)

        // Draw text outward along the radius. Flip labels on the left half so they remain
        // upright while the wheel is stationary and naturally rotate during the spin.
        val normalized = normalizeDegrees(centerAngle)
        if (normalized in 90f..270f) {
            canvas.rotate(180f, cx, cy)
            canvas.drawText(label, cx - textRadius, cy + textPaint.textSize * 0.35f, textPaint)
        } else {
            canvas.drawText(label, cx + textRadius, cy + textPaint.textSize * 0.35f, textPaint)
        }
        canvas.restore()
    }

    private fun fitText(value: String, maxWidth: Float, p: Paint): String {
        val clean = value.trim().ifBlank { "Unnamed" }
        if (p.measureText(clean) <= maxWidth) return clean
        if (maxWidth <= p.measureText("…")) return "…"

        var end = clean.length
        while (end > 1 && p.measureText(clean.substring(0, end) + "…") > maxWidth) {
            end--
        }
        return clean.substring(0, end.coerceAtLeast(1)) + "…"
    }

    private fun buildSegments(source: List<Pair<Int, String>>): List<WheelSegment> {
        if (source.isEmpty()) return emptyList()

        data class MutableSegment(
            val displayName: String,
            val tickets: MutableList<Pair<Int, String>>
        )

        val grouped = linkedMapOf<String, MutableSegment>()
        source.forEach { ticket ->
            val display = ticket.second.trim().ifBlank { "Unnamed" }
            val key = display.lowercase(Locale.ROOT)
            val segment = grouped.getOrPut(key) {
                MutableSegment(display, mutableListOf())
            }
            segment.tickets += ticket
        }

        return grouped.values.map { WheelSegment(it.displayName, it.tickets.toList()) }
    }

    private fun drawPointer(canvas: Canvas, cx: Float, y: Float, size: Float) {
        val pointer = Path().apply {
            moveTo(cx, y + size * 0.07f)
            lineTo(cx - size * 0.04f, y)
            lineTo(cx + size * 0.04f, y)
            close()
        }
        paint.color = Ui.BLUE
        paint.style = Paint.Style.FILL
        canvas.drawPath(pointer, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        paint.color = Color.WHITE
        canvas.drawPath(pointer, paint)
        paint.style = Paint.Style.FILL
    }

    private fun normalizeDegrees(value: Float): Float {
        val normalized = value % 360f
        return if (normalized < 0f) normalized + 360f else normalized
    }
}
